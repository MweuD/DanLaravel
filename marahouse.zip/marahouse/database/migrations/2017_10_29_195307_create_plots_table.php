<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePlotsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('plots', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name');
            $table->integer('no_of_houses');
            $table->integer('number_of_vacants');
            $table->string('location');
            $table->string('type');
            $table->longText('description');
            $table->integer('max_no_of_tenants');
            $table->integer('landlord_id')->unsigned();
            $table->foreign('landlord_id')->references('id')->on('landlords');
            $table->integer('rent');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('plots');
    }
}
