<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-1">
            <a class="btn btn-info" type="button" href="/admin/home">Back</a>
        </div>
        <div class="col-md-11">
            <div class="panel panel-info">
                <div class="panel-heading" style="padding: 3px">
                    <h1 class="text-center">Edit Landlords Details</h1>
                </div>
                
                <div class="panel-body">
                <table class="table table-striped">
                    <thead>
                        <tr class="text-danger">
                            <th>Serial No</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Description</th>
                            <th>Telephone</th>
                            <th>Id Number</th>
                            <th>Edit</th>
                        </tr>
                    </thead>
                    <?php $__currentLoopData = $landlords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $landlord): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tbody>
                        <tr>
                            <td><?php echo e($landlord->id); ?></td>
                            <td><?php echo e($landlord->surname); ?> <?php echo e($landlord->lastname); ?> <?php echo e($landlord->firstname); ?></td>
                            <td><?php echo e($landlord->email); ?></td>
                            <td><?php echo e($landlord->market); ?></td>
                            <td><?php echo e($landlord->tel_no); ?></td>
                            <td><?php echo e($landlord->id_no); ?></td>
                            <td><a href="/landlords/<?php echo e($landlord->id); ?>/edit">Edit </a><i class="fa fa-edit fa-lg"></i></td>
                        </tr>
                    </tbody>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
                </div>
                
            
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>