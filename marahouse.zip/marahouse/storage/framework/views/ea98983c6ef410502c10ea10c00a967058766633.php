<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<div class="col-md-6 col-md-offset-3">
			<div class="panel panel-info">
				<div class="panel-heading">
					<h2 class="text-center">Edit My Details</h2>
				</div>
				<div class="panel-body">
					<form method="POST" action="<?php echo e(route('landlords.update',[$landlord->id])); ?>">
						<input type="hidden" name="_method" value="put">
						<?php echo e(csrf_field()); ?>

						<div class="col-md-6">
							<div class="form-group">
								<label for="surname">Surname</label>
								<input type="text" name="surname" value="<?php echo e($landlord->surname); ?>" class="form-control" placeholder="Enter surname">
							</div>

							<div class="form-group">
								<label for="lastname">Lastname</label>
								<input type="text" name="lastname" value="<?php echo e($landlord->lastname); ?>" class="form-control" placeholder="Enter lastname">
							</div>

							<div class="form-group">
								<label for="firstname">Firstname</label>
								<input type="text" name="firstname" value="<?php echo e($landlord->firstname); ?>" class="form-control" placeholder="Enter firstname">
							</div>
							<div class="form-group">
								<label for="email">Email</label>
								<input type="text" name="email" value="<?php echo e($landlord->email); ?>" class="form-control" placeholder="Enter Email">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label for="age">Age</label>
								<input type="text" name="age" value="<?php echo e($landlord->age); ?>" class="form-control" placeholder="Enter age">
							</div>
							<div class="form-group">
								<label for="tel_no">Telephone</label>
								<input type="text" name="tel_no" value="<?php echo e($landlord->tel_no); ?>" class="form-control" placeholder="Enter telephone">
							</div>
							<div class="form-group">
								<label for="id_no">Id No.</label>
								<input type="text" name="id_no" value="<?php echo e($landlord->id_no); ?>" class="form-control" placeholder="Enter Id No">
							</div>
							<div class="form-group">
							<button type="submit" class="btn btn-primary">Edit Details</button>
							</div>

						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>