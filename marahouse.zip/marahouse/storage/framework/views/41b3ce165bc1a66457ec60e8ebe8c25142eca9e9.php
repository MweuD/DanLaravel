<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <div class="panel panel-info">
                <div class="panel-heading" style="padding: 2px">
               <h2 class="text-center">User Registration</h2>
            </div>

                <div class="panel-body">
                    <form method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <div id="left" style="float:left">
                        <div class="form-group<?php echo e($errors->has('surname') ? ' has-error' : ''); ?>">
                            <label for="surname" class=" control-label">Surname</label>

                            
                                <input id="surname" type="text" class="form-control" name="surname" value="<?php echo e(old('surname')); ?>" required autofocus>

                                <?php if($errors->has('surname')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('surname')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            
                        </div>
                        <div class="form-group<?php echo e($errors->has('lastname') ? ' has-error' : ''); ?>">
                            <label for="lastname" class=" control-label">Last Name</label>

                            
                                <input id="lastname" type="text" class="form-control" name="lastname" value="<?php echo e(old('lastname')); ?>" required autofocus>

                                <?php if($errors->has('lastname')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('lastname')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('firstname') ? ' has-error' : ''); ?>">
                            <label for="firstname" class=" control-label">First Name</label>

                            
                                <input id="firstname" type="text" class="form-control" name="firstname" value="<?php echo e(old('firstname')); ?>" required autofocus>

                                <?php if($errors->has('firstname')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('firstname')); ?></strong>
                                    </span>
                                <?php endif; ?>
                           
                        </div>

                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label for="email" class=" control-label">E-mail Address</label>

                            
                                <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required>

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            
                        </div>
                        <div class="form-group<?php echo e($errors->has('gender') ? ' has-error' : ''); ?>">
                            <label for="gender" class=" control-label">Gender</label>

                            
                                <input id="gender" type="text" class="form-control" name="gender" value="<?php echo e(old('gender')); ?>" required autofocus>

                                <?php if($errors->has('gender')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('gender')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            
                        </div>
                    </div>
                    <div id="right" style="float: right">
                        <div class="form-group<?php echo e($errors->has('age') ? ' has-error' : ''); ?>">
                            <label for="age" class=" control-label">Age</label>

                            
                                <input id="age" type="text" class="form-control" name="age" value="<?php echo e(old('age')); ?>" required autofocus maxlength="2">

                                <?php if($errors->has('age')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('age')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            
                        </div>
                        <div class="form-group<?php echo e($errors->has('tel_no') ? ' has-error' : ''); ?>">
                            <label for="tel_no" class=" control-label">Telephone Number</label>

                            
                                <input id="tel_no" type="text" class="form-control" name="tel_no" value="<?php echo e(old('tel_no')); ?>" required autofocus maxlength="11">

                                <?php if($errors->has('tel_no')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('tel_no')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            
                        </div>
                        <div class="form-group<?php echo e($errors->has('id_no') ? ' has-error' : ''); ?>">
                            <label for="id_no" class=" control-label">ID Number</label>

                            
                                <input id="id_no" type="text" class="form-control" name="id_no" value="<?php echo e(old('id_no')); ?>" required autofocus maxlength="11">

                                <?php if($errors->has('id_no')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('id_no')); ?></strong>
                                    </span>
                                <?php endif; ?>
            
                        </div>

                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <label for="password" class=" control-label">Password</label>

                            
                                <input id="password" type="password" class="form-control" name="password" required maxlength="15">

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                        
                        </div>

                        <div class="form-group">
                            <label for="password-confirm" class=" control-label">Confirm Password</label>

                            
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-7 col-md-offset-2">
                            <button type="submit" class="btn btn-primary btn-block">
                                        Register
                            </button>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>