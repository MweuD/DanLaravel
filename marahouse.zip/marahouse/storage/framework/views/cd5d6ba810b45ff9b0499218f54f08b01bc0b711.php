<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <h1 style="background:linear-gradient(to left, white 0%, cornflowerblue 100%); text-align:center; padding:15px; border-radius:100px; color: white">Hello <?php echo e(Auth::user()->surname); ?></h1>
        <hr>
    <div class="col-md-3">
        <h3>Manage my Plots</h3>
        <ol class="list-unstyled">
            <li><a href="/plots/" class="btn btn-link btn-sm">View my Plot <i class="fa fa-eye"></a></i></li>
            <li><a href="" class="btn btn-link btn-sm">Add a new Plot <i class="fa fa-plus"></i></a></li>
            <li><a href="" class="btn btn-link btn-sm">Delete a Plot <i class="fa fa-remove"></i></a></li>
            <li><a href="" class="btn btn-link btn-sm">Add a vacant</a><i class="fa fa-add"></i></li>
            <li><a href="" class="btn btn-link btn-sm">Remove a Vacant</a><i class="fa fa-eye"></i></li>
        </ol>
    </div>
    
    <div class="col-md-9">
        <div class="jumbotron text-center" style="padding: 5px; background: lavender">
            <h2>Welcome to Marahousing.com</h2>
            <hr>
            <h3>Need a house?</h3>
            <p>Marahousing.com is here to help you find a better home for you. You are now able to get connected to landlords, view their houses and book the one of your choice. Hurry up, don't be late.</p>
            <a class="btn btn-primary animated infinite flash btn-lg" href="/landlords/">Book Now!!</a>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.apps', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>