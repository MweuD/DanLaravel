@extends('layouts.apps')

@section('content')
<div class="container" style="color: rgb(33, 37, 41); font-size: 20px; font-family: Helvetica Neue,Arial,sans-serif">
    <div class="row">
        <div class="heading">
            <h1 style="padding: 0px"><img src="images/9.jpg" height="130px" style="padding-right: 70px">Welcome to Marahousing</h1>
        </div>
        <div class="col-md-9">
            <div class="jumbotron text-center" style="background: rgb(233, 236, 239); padding: 12px;">
                <h2 class="text-center text-info">Hello {{Auth::user()->surname}}</h2>
                <p style="color: rgb(33, 37, 41); font-size: 20px; font-family: Helvetica Neue,Arial,sans-serif">Marahousing.com is here to help you find a better home for you. You are now able to get connected to landlords, view their houses and book the one of your choice. Hurry up, don't be late. Be the first one to get the home of your dream. </p>
                <hr>
                <p>Home is where the heart is.</p>
                <a class="btn btn-primary btn-lg animated infinite tada" href="/landlords/">Get Started Now</a>
            </div>
            <div class="col-md-12">
                    <h1 style="background:linear-gradient(to left, white 0%, cornflowerblue 100%); text-align:center; padding:10px; border-radius:100px; color: white">A place for you</h1>
        <hr>
            </div>
                <div class="col-md-3">
                    <a href="#" class="thumbnail">
                        <img src="images/1.jpeg" style="width: 100%; height: 150px">
                    </a>
                </div>
                <div class="col-md-3">
                    <a href="#" class="thumbnail">
                        <img src="images/2.jpeg" style="width: 100%; height: 150px">
                    </a>
                </div>
                <div class="col-md-3">
                    <a href="#" class="thumbnail">
                        <img src="images/3.jpeg" style="width: 100%; height: 150px">
                    </a>
                </div>
                <div class="col-md-3">
                    <a href="#" class="thumbnail">
                        <img src="images/4.jpeg" style="width: 100%; height: 150px">
                    </a>
                </div>
                <div class="col-md-3">
                    <a href="#" class="thumbnail">
                        <img src="images/5.jpeg" style="width: 100%; height: 150px">
                    </a>
                </div>
                <div class="col-md-3">
                    <a href="#" class="thumbnail">
                        <img src="images/6.jpeg" style="width: 100%; height: 150px">
                    </a>
                </div>
                <div class="col-md-3">
                    <a href="#" class="thumbnail">
                        <img src="images/7.jpeg" style="width: 100%; height: 150px">
                    </a>
                </div>
                <div class="col-md-3">
                    <a href="#" class="thumbnail">
                        <img src="images/8.jpeg" style="width: 100%; height: 150px">
                    </a>
                </div>
        </div>
        <div class="col-md-3">
            <h3>My Tasks</h3>
        <ol class="list-unstyled">
            <li><a href="" class="btn btn-link btn-sm">View Houses</a><i class="fa fa-eye"></i></li>
            <li><a href="users/{{Auth::user()->id}}/edit" class="btn btn-link btn-sm">Edit My Profile</a><i class="fa fa-edit"></i></li>
        </ol>
        <div id="myCarousel" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                <li data-target="#myCarousel" data-slide-to="1"></li>
                <li data-target="#myCarousel" data-slide-to="2"></li>
                <li data-target="#myCarousel" data-slide-to="3"></li>
                <li data-target="#myCarousel" data-slide-to="4"></li>
                <li data-target="#myCarousel" data-slide-to="5"></li>
                <li data-target="#myCarousel" data-slide-to="6"></li>
                <li data-target="#myCarousel" data-slide-to="7"></li>
                
            </ol>
            <div class="carousel-inner">
                <div class="item active">
                    <img src="images/1.jpeg" alt="" style="width: 100%; height: 150px">
                    <div class="carousel-caption">
                        <h1></h1>
                    </div>
                </div>
                <div class="item">
                    <img src="images/2.jpeg" alt="" style="width: 100%; height: 150px">
                    <div class="carousel-caption">
                        <h1></h1>
                    </div>
                </div>
                <div class="item">
                    <img src="images/3.jpeg" alt="" style="width: 100%; height: 150px">
                    <div class="carousel-caption">
                        <h1></h1>
                    </div>
                </div>
                <div class="item">
                    <img src="images/4.jpeg" alt="" style="width: 100%; height: 150px">
                    <div class="carousel-caption">
                        <h1></h1>
                    </div>
                </div>
                <div class="item">
                    <img src="images/5.jpeg" alt="" style="width: 100%; height: 150px">
                    <div class="carousel-caption">
                        <h1></h1>
                    </div>
                </div>
                <div class="item">
                    <img src="images/6.jpeg" alt="" style="width: 100%; height: 150px">
                    <div class="carousel-caption">
                        <h1></h1>
                    </div>
                </div>
                <div class="item">
                    <img src="images/7.jpeg" alt="" style="width: 100%; height: 150px">
                    <div class="carousel-caption">
                        <h1></h1>
                    </div>
                </div>
                <div class="item">
                    <img src="images/8.jpeg" alt="" style="width: 100%; height: 150px">
                    <div class="carousel-caption">
                        <h1></h1>
                    </div>
                </div>
            </div>
        </div>
        <h1 class="text-center"><button type="button" class="btn btn-info btn-lg animated infinite pulse" data-target=".well" data-toggle="collapse"><i class="fa fa-info-circle"></i> About Me</button></h1>
     <hr>
     <div class="well well-sm collapse text-center" style="padding: 0px; line-height: 5px; width: 100%; border-radius: 100px">
         <h4>About Me <i class="fa fa-edit"></i></h4>
        <p>Name</p>
         <p style=" font-size: 12px"><i class="fa fa-contact"></i>{{Auth::user()->lastname}}</p>
         <p>Telephone</p>
         <p style=" font-size: 12px"><i class="fa fa-contact"></i>{{Auth::user()->tel_no}}</p>
         <p>Age</p>
         <p style=" font-size: 12px"><i class="fa fa-contact"></i>{{Auth::user()->age}}</p>
         <p>Gender</p>
         <p style=" font-size: 12px"><i class="fa fa-contact"></i>{{Auth::user()->gender}}</p>
        
     </div> 
     <div class="panel panel-success text-center">
         <div class="panel-heading">
             <h2>Need a vacant?</h2>
         </div>
         <div class="panel-body">
             <p>We have spacial services for you {{Auth::user()->surname}}. Click the link below to enjoy our services..</p>
         </div>
         <div class="panel-footer">
             <a type="button" class="btn btn-success animated infinite jackInTheBox" href="/landlords/">View</a>
         </div>
     </div>  
    </div>
</div>
@endsection
