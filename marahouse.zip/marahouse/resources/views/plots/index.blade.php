@extends('layouts.app')
@section('content')
<div class="container">
	<div class="row">
		<div class="col-md-6 col-md-offset-3">
			<div class="panel panel-default">
				<div class="panel-heading">
					<h2>My Plots</h2>
				</div>
				@foreach($landlords as $landlord)
				@endforeach
				@foreach($landlord->plots as $plot)
				<p>{{$plot->name}}</p>
				@endforeach
			</div>
		</div>
	</div>
</div>
@endsection