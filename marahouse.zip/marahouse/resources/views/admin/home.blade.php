@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2" style="background-color: white">
            <div class="page-header">
                <h1 class="text-center">MaraBooking.Com</h1>
            </div>
            <div class="panel panel-default">
                <div class="panel-heading" style="padding: 0px">
                    <h3 class="text-center">Manage Landlords</h3>
                </div>
                <div class="panel-body">
                    <div class="well well-sm">
                        <h4 class="text-center"><a href="">Add Landlord</a></h4>
                        <h4 class="text-center"><a href="">Delete Landlord</a></h4>
                        <h4 class="text-center"><a href="/admin/editing">Edit Landlord</a></h4>
                        <h4 class="text-center"><a href="/admin/show">View Landlords</a></h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
