@extends('layouts.app')
@section('content')
<div class="container">
	<div class="row">
		<div class="col-md-6 col-md-offset-3">
			<div class="panel panel-info">
				<div class="panel-heading">
					<h2 class="text-center">Edit My Details</h2>
				</div>
				<div class="panel-body">
					<form method="POST" action="{{ route('landlords.update',[$landlord->id]) }}">
						<input type="hidden" name="_method" value="put">
						{{csrf_field()}}
						<div class="col-md-6">
							<div class="form-group">
								<label for="surname">Surname</label>
								<input type="text" name="surname" value="{{$landlord->surname}}" class="form-control" placeholder="Enter surname">
							</div>

							<div class="form-group">
								<label for="lastname">Lastname</label>
								<input type="text" name="lastname" value="{{$landlord->lastname}}" class="form-control" placeholder="Enter lastname">
							</div>

							<div class="form-group">
								<label for="firstname">Firstname</label>
								<input type="text" name="firstname" value="{{$landlord->firstname}}" class="form-control" placeholder="Enter firstname">
							</div>
							<div class="form-group">
								<label for="email">Email</label>
								<input type="text" name="email" value="{{$landlord->email}}" class="form-control" placeholder="Enter Email">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label for="age">Age</label>
								<input type="text" name="age" value="{{$landlord->age}}" class="form-control" placeholder="Enter age">
							</div>
							<div class="form-group">
								<label for="tel_no">Telephone</label>
								<input type="text" name="tel_no" value="{{$landlord->tel_no}}" class="form-control" placeholder="Enter telephone">
							</div>
							<div class="form-group">
								<label for="id_no">Id No.</label>
								<input type="text" name="id_no" value="{{$landlord->id_no}}" class="form-control" placeholder="Enter Id No">
							</div>
							<div class="form-group">
							<button type="submit" class="btn btn-primary">Edit Details</button>
							</div>

						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection
