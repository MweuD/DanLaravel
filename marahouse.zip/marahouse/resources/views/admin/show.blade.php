@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-1">
            <a class="btn btn-info" type="button" href="/admin/home">Back</a>
        </div>
        <div class="col-md-11">
            <div class="panel panel-info">
                <div class="panel-heading" style="padding: 3px">
                    <h1 class="text-center">My Landlords</h1>
                </div>
                
                <div class="panel-body">
                <table class="table table-striped">
                    <thead>
                        <tr class="text-danger">
                            <th>Serial No</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Description</th>
                            <th>Telephone</th>
                            <th>Id Number</th>
                        </tr>
                    </thead>
                    @foreach($landlords as $landlord)
                    <tbody>
                        <tr>
                            <td>{{$landlord->id}}</td>
                            <td>{{$landlord->surname}} {{$landlord->lastname}} {{$landlord->firstname}}</td>
                            <td>{{$landlord->email}}</td>
                            <td>{{$landlord->market}}</td>
                            <td>{{$landlord->tel_no}}</td>
                            <td>{{$landlord->id_no}}</td>
                        </tr>
                    </tbody>
                    @endforeach
                </table>
                </div>
                
            
            </div>
        </div>
    </div>
</div>
@endsection
