<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
    <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
    <script src="https://use.fontawesome.com/874dbadbd7.js"></script>
    <title>Contact Us</title>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
	<div class="container">
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
	    <span class="navbar-toggler-icon"></span>
	    </button>
	  	<div class="collapse navbar-collapse" id="navbarTogglerDemo01">
	    <a class="navbar-brand" href="">Marahousing</a>
	    <ul class="navbar-nav mr-auto mt-2 mt-lg-0 navbar-right">
	      <li class="nav-item">
	        <a class="nav-link" href="/">Homepage<span class="sr-only">(current)</span></a>
	      </li>
	      <li class="nav-item">
	        <a class="nav-link" href="/about">About Us</a>
	      </li>
	      <li class="nav-item active">
	        <a class="nav-link" href="/contact">Contact Us</a>
	      </li>
	      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="http://example.com" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Join Us
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="{{ route('login')}}">Login</a>
          <a class="dropdown-item" href="{{ route('register')}}">Register</a>
        </div>
      </li>

	    </ul>
	    <form class="form-inline my-2 my-lg-0">
	      <input class="form-control mr-sm-2" type="text" placeholder="Search" aria-label="Search">
	      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    	</form>
    </div>
</nav>
<div class="container">
	<div class="row" style="padding-top: 35px">
		<div class="col-md-3">
			<div class="card">
			  <img class="card-img-top" src="images/9.jpg" alt="Card image cap">
			  <div class="card-body">
			    <h4 class="card-title">Our Services</h4>
			    		<ul class="list-group">
			    			<li class="list-group-item">Marketing</li>
			    			<li class="list-group-item">Booking services</li>
			    			<li class="list-group-item">Management</li>
			    		</ul>
			  </div>
			</div>
		</div>
		<div class="col-md-9">
					<div class="jumbotron text-center">
						<h1 class="display-5 text-info">Contact us</h1>
						<p class="lead">For landlords registration or any other issues or queries, we ready to help. Our agents are available 24/7 ready to address your queries.</p>
						<p>Please contact them via the following contacts</p>
						<p class="text-primary">+25412558812/+254724069930</p>
						<p class="text-info">jeremiah.mweu@gmail.com</p>
						<p>Marahousing closes the gap between the tenants and landlords. Join us now and start enjoying our services</p>
						<hr class="m-y-md">
						<p class="lead text-center">
							<a class="btn btn-primary btn-lg" href="{{route('register')}}" role="button">Join us now</a>
						</p>
					</div>
		</div>
	</div>
</div>

<!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script> -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
</body>

</html>