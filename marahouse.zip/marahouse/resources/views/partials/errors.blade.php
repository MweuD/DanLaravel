@if (session()->has('success'))
	<div class="alert alert-success alert-dismissable">
		<button type="button" class="close" data-dismiss="alert">&times;</button>
	</div>
	<strong>{!!session()->get('success')!!}</strong>
@endif