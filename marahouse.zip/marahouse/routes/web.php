<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('/landlords/', 'HomeController@edit')->name('edit');
Route::get('/admin/show', 'AdminsController@index');
Route::get('/plots/', 'LandController@get');

Route::get('about', function() {
    return view('/about');
});
Route::get('contact', function() {
    return view('/contact');
});

Route::get('/admin/editing', 'AdminsController@index');
Route::get('/admin/show', 'AdminController@indexy');
Route::get('/admin/edit', 'AdminController@edit');
Route::get('/admin/edit', 'AdminController@update');


Route::resource('landlords','LandlordsController');
Route::resource('users','UsersController');
Route::resource('plots','PlotsController');

Route::get('/land/home','LandController@index')->name('land.home');
Route::get('/land', 'Land\LoginController@showLoginForm')->name('land.login');
Route::post('/land', 'Land\LoginController@login');
Route::post('land-password/email', 'Land\ForgotPasswordController@sendResetLinkEmail')->name('land.password.email');
Route::get('land-password/reset', 'Land\ForgotPasswordController@showLinkRequestForm')->name('land.password.request');
Route::post('land-password/reset', 'Land\ResetPasswordController@reset');
Route::get('password/reset/{token}','Land\ResetPasswordController@showResetForm')->name('land.password.reset');
Route::get('/land/register','Land\RegisterController@showRegistrationForm')->name('land.register');
Route::post('/land/register', 'Land\RegisterController@register');


Route::get('/admin/home','AdminController@index')->name('admin.home');
Route::get('/admin', 'Admin\LoginController@showLoginForm')->name('admin.login');
Route::post('/admin', 'Admin\LoginController@login');
Route::post('admin-password/email', 'admin\ForgotPasswordController@sendResetLinkEmail')->name('admin.password.email');
Route::get('admin-password/reset', 'Admin\ForgotPasswordController@showLinkRequestForm')->name('admin.password.request');
Route::post('admin-password/reset', 'Admin\ResetPasswordController@reset');
Route::get('password/reset/{token}','Admin\ResetPasswordController@showResetForm')->name('admin.password.reset');