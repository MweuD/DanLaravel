<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Plot extends Model
{
    protected $fillable=[
  'name',
  'landlord_id',
  'tenant_id',
  'no_of_houses',
  'number_of_vacants',
  'location',
  'type',
  'description',
  'max_no_of_tenants',
    ];
  public function landlord(){
      return $this->belongsTo('App\Landlord');
    }
}

