<?php

namespace App\Http\Controllers;
use App\Landlord;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth:admin');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    { 
        return view('admin/home');
    }
     public function indexy()
    {
        $landlords=Landlord::all();
        return view('admin.show',['landlords'=>$landlords]);
    }
     public function edit(Landlord $landlord)
    {
        $landlord= Landlord::find($landlord->id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Landlord  $landlord
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Landlord $landlord)
    {
        $landlordUpdate=Landlord::where('id', $landlord->id)->update([
            'surname'=>$request->input('surname'),
            'lastname'=>$request->input('lastname'),
            'firstname'=>$request->input('firstname'),
            'email'=>$request->input('email'),
            'tel_no'=>$request->input('tel_no'),
            'id_no'=>$request->input('id_no')
        ]);
       return view('admin.edit');
    }
}
