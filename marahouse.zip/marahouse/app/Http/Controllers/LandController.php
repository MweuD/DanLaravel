<?php

namespace App\Http\Controllers;
use App\Landlord;
use Illuminate\Http\Request;

class LandController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth:landlord');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    { 
        $landlords=Landlord::all();
        return view('land/home');
    }
    public function get()
    {
        $landlords=Landlord::all();
        return view('plots.index', ['landlords'=>$landlords]);
    }
}
